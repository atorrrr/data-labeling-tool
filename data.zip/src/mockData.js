﻿// mockData.js

export const casesData = [
  {
    caseId: "Case #10001",
    summary:
      "Multiple suspicious transactions and call activity related to a stolen credit card.",
    overallAiInsight: {
      confidence: 92,
      summaryExplanation:
        "Several calls referenced unauthorized transactions and location discrepancies, indicating possible fraud."
    },
    events: [
      {
        eventId: "c1",
        eventType: "Call",
        timestamp: "2025-02-03T08:15:00",
        shortDescription: "Caller reports unauthorized use of credit card",
        textSummary:
          "Customer called at 08:15 reporting multiple unauthorized charges. There were discrepancies in the transaction locations.",
        callSegments: [
          {
            segmentId: "segA",
            transcript: "Caller: 'I just saw charges I never made on my card.'",
            audioUrl: "/mock-audio/call-1-segA.mp3",
            aiConfidence: 88,
            aiExplanation:
              "High confidence that the caller is reporting a fraud incident."
          },
          {
            segmentId: "segB",
            transcript: "Agent: 'I see some foreign transactions. Let me check further.'",
            audioUrl: "/mock-audio/call-1-segB.mp3",
            aiConfidence: 85,
            aiExplanation:
              "Agent notices location inconsistency, suggesting potential fraud."
          }
        ],
        // New extracted Q/A for calls:
        extractedQuestions: [
          {
            question:
              "When did you first notice the unauthorized transactions?",
            answer:
              "I noticed them this morning when I checked my account."
          },
          {
            question:
              "Have you shared your card details with anyone recently?",
            answer: "No, I haven't shared my card details with anyone."
          }
        ],
        referencedTransactions: ["TXN-1001", "TXN-1002"],
        details: {}
      },
      {
        eventId: "t1",
        eventType: "Transaction",
        timestamp: "2025-02-03T09:00:00",
        shortDescription: "Unauthorized overseas transaction flagged",
        textSummary:
          "A $1,200 transaction was flagged due to its unusual overseas location.",
        callSegments: [],
        transcript:
          "System alert: Unusual transaction detected at 09:00 for $1,200 from a foreign location.",
        details: {
          transactionId: "TXN-1001",
          amount: "1200 USD",
          location: "Foreign"
        },
        audioUrl: null,
        aiConfidence: 82,
        aiExplanation:
          "Transaction amount and location deviate from historical patterns."
      },
      {
        eventId: "a1",
        eventType: "Alert",
        timestamp: "2025-02-03T09:30:00",
        shortDescription: "Fraud alert triggered",
        textSummary:
          "The system generated an alert due to multiple suspicious activities.",
        callSegments: [],
        transcript: null,
        details: {
          alertId: "ALERT-500",
          reason:
            "Multiple foreign transactions detected within a short timeframe."
        },
        audioUrl: null,
        aiConfidence: 80,
        aiExplanation:
          "A rapid sequence of suspicious transactions triggered the alert."
      },
      {
        eventId: "l1",
        eventType: "Login",
        timestamp: "2025-02-03T07:50:00",
        shortDescription: "Multiple failed login attempts detected",
        textSummary:
          "Several failed login attempts from an unrecognized IP preceded a successful login.",
        callSegments: [
          {
            segmentId: "segL1",
            transcript:
              "System: 'Failed login attempt from IP 192.168.10.45.'",
            audioUrl: null,
            aiConfidence: 75,
            aiExplanation:
              "Repeated login failures from a suspicious IP address."
          }
        ],
        details: {
          ipAddress: "192.168.10.45",
          loginStatus: "Failed then successful"
        }
      }
    ]
  },
  {
    caseId: "Case #20002",
    summary:
      "Suspected account takeover with unusual login activity and unauthorized call reports.",
    overallAiInsight: {
      confidence: 95,
      summaryExplanation:
        "Unusual login behavior and multiple calls reporting account lockouts indicate a possible account takeover."
    },
    events: [
      {
        eventId: "l2",
        eventType: "Login",
        timestamp: "2025-02-03T02:10:00",
        shortDescription: "Login failure from a new device",
        textSummary:
          "Login at 02:10 from an unrecognized device resulted in account lockout after several failed attempts.",
        callSegments: [
          {
            segmentId: "segL2",
            transcript:
              "System: 'Multiple login failures detected from device ID XYZ123.'",
            audioUrl: null,
            aiConfidence: 70,
            aiExplanation:
              "An unusual device triggered security protocols after repeated login failures."
          }
        ],
        details: {
          deviceId: "XYZ123",
          ipAddress: "192.168.45.3"
        }
      },
      {
        eventId: "c2",
        eventType: "Call",
        timestamp: "2025-02-03T03:00:00",
        shortDescription: "User reports unauthorized account changes",
        textSummary:
          "Call at 03:00 regarding unexpected account lockouts and password change attempts.",
        callSegments: [
          {
            segmentId: "segC2",
            transcript:
              "Caller: 'I didn’t request any password changes, why is my account locked?'",
            audioUrl: "/mock-audio/call-2-segC2.mp3",
            aiConfidence: 90,
            aiExplanation:
              "The caller is confused over unauthorized account changes, suggesting possible compromise."
          },
          {
            segmentId: "segC3",
            transcript:
              "Agent: 'We have detected login activity from multiple new devices. We’ll escalate this issue.'",
            audioUrl: "/mock-audio/call-2-segC3.mp3",
            aiConfidence: 85,
            aiExplanation:
              "Multiple device logins support the suspicion of an account takeover."
          }
        ],
        extractedQuestions: [
          {
            question: "Did you authorize any recent password changes?",
            answer: "No, I did not authorize any password changes."
          },
          {
            question:
              "Have you noticed any suspicious emails or notifications?",
            answer:
              "I received a couple of odd emails but wasn't sure if they were related."
          }
        ],
        referencedTransactions: [],
        details: {}
      },
      {
        eventId: "a2",
        eventType: "Alert",
        timestamp: "2025-02-03T04:00:00",
        shortDescription: "Account takeover alert",
        textSummary:
          "The security system flagged a possible account takeover due to unusual login and call activity.",
        callSegments: [],
        details: {
          alertId: "ALERT-987",
          reason:
            "High risk due to multiple failed logins and unauthorized account change attempts."
        },
        transcript: null,
        audioUrl: null,
        aiConfidence: 88,
        aiExplanation:
          "Security algorithms identified high-risk behavior based on login patterns and call reports."
      }
    ]
  }
];
