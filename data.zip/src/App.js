﻿import React, { useState, useMemo, useEffect } from 'react';
import { casesData } from './mockData';
import {
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  InputBase,
  Box,
  Drawer,
  List,
  ListItem,
  ListItemText,
  FormGroup,
  FormControlLabel,
  Checkbox,
  Slider,
  TextField,
  Paper,
  Button,
  Switch,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  CssBaseline,
  Tabs,
  Tab
} from '@mui/material';
import { Search, Notifications, Settings, Help, Brightness4, Brightness7 } from '@mui/icons-material';
import { styled, createTheme, ThemeProvider } from '@mui/material/styles';

// --- Event Color Mapping ---
// Changed: Transaction events now use a Material Green,
// while Login events now use Material Blue.
function eventColor(type) {
  switch (type) {
    case 'Call': return 'orange';
    case 'Transaction': return '#4caf50'; // green
    case 'Login': return '#2196f3'; // blue
    case 'Alert': return 'red';
    default: return 'gray';
  }
}

// --- Styled Components ---
const MainContainer = styled('div')({
  display: 'flex',
  flex: 1,
  height: '100%',
});

const Sidebar = styled(Drawer)({
  width: 280,
  flexShrink: 0,
  '& .MuiDrawer-paper': {
    width: 280,
    boxSizing: 'border-box',
    padding: '16px'
  },
});

const TimelineColumn = styled('div')({
  flex: 3,
  display: 'flex',
  flexDirection: 'column',
  overflowY: 'auto',
});

const DetailColumn = styled('div')({
  flex: 1,
  display: 'flex',
  flexDirection: 'column',
  gap: '16px',
  padding: '16px'
});

const TimelineContainer = styled(Paper)({
  margin: '16px',
  padding: '16px',
  position: 'relative',
  overflowX: 'auto'
});

const TimelineBar = styled('div')({
  position: 'relative',
  height: '40px',
  borderBottom: '2px solid #ccc',
  marginTop: '10px',
  marginBottom: '20px'
});

const TimelineMarker = styled('div')(({ leftPos, color }) => ({
  position: 'absolute',
  left: leftPos,
  top: '0px',
  width: '20px',
  height: '20px',
  backgroundColor: color,
  borderRadius: '50%',
  cursor: 'pointer',
  transform: 'translate(-50%, 0)',
  '&:hover': {
    opacity: 0.8
  }
}));

const TimelineLabel = styled('div')(({ leftPos }) => ({
  position: 'absolute',
  left: leftPos,
  top: '45px',
  fontSize: '12px',
  transform: 'translateX(-50%)',
  color: '#666'
}));

const FooterBar = styled('footer')({
  backgroundColor: '#f5f5f5',
  padding: '8px 16px',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center'
});

// --- TabPanel Helper ---
function TabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`call-tabpanel-${index}`}
      aria-labelledby={`call-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 2 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

// --- Main Component ---
export default function App() {
  // App states
  const [selectedCase, setSelectedCase] = useState(null);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showCall, setShowCall] = useState(true);
  const [showTransaction, setShowTransaction] = useState(true);
  const [showLogin, setShowLogin] = useState(true);
  const [showAlert, setShowAlert] = useState(true);
  const [confidenceLevel, setConfidenceLevel] = useState(0);
  const [keyword, setKeyword] = useState('');
  const [showGroundTruth, setShowGroundTruth] = useState(false);
  const [timelineSummary, setTimelineSummary] = useState('');
  const [darkMode, setDarkMode] = useState(false);
  // For call event details tabbing (Transcript vs. Extracted Q/A)
  const [callDetailTab, setCallDetailTab] = useState(0);

  const filteredCases = casesData;

  // Create theme with dark mode toggle.
  const theme = useMemo(() => createTheme({
    palette: {
      mode: darkMode ? 'dark' : 'light',
    }
  }), [darkMode]);

  // Whenever the selected event changes, reset the call detail tab.
  useEffect(() => {
    setCallDetailTab(0);
  }, [selectedEvent]);

  // Helper: Compute left position (%) for a given "HH:MM" timestamp.
  function computeLeftPosition(timestamp) {
    if (!timestamp) return '0%';
    const [hh, mm] = timestamp.split(':').map(Number);
    const totalMins = (hh * 60) + (mm || 0);
    return `${(totalMins / 1440) * 100}%`;
  }

  // Filter events based on selected case, event type, confidence, and keyword.
  function getFilteredEvents() {
    if (!selectedCase) return [];
    return selectedCase.events.filter((evt) => {
      let typeCheck = false;
      if (evt.eventType === 'Call' && showCall) typeCheck = true;
      if (evt.eventType === 'Transaction' && showTransaction) typeCheck = true;
      if (evt.eventType === 'Login' && showLogin) typeCheck = true;
      if (evt.eventType === 'Alert' && showAlert) typeCheck = true;

      let evtConf = evt.aiConfidence || 0;
      if (Array.isArray(evt.callSegments) && evt.callSegments.length > 0) {
        const segMax = Math.max(...evt.callSegments.map(s => s.aiConfidence || 0));
        evtConf = Math.max(evtConf, segMax);
      }
      const confidenceCheck = evtConf >= confidenceLevel;

      if (!keyword.trim()) {
        return typeCheck && confidenceCheck;
      } else {
        const k = keyword.trim().toLowerCase();
        let text = (evt.transcript || '').toLowerCase();
        if (evt.callSegments?.length) {
          evt.callSegments.forEach(seg => {
            text += seg.transcript.toLowerCase();
          });
        }
        text += (evt.shortDescription || '').toLowerCase();
        text += (evt.textSummary || '').toLowerCase();
        return typeCheck && confidenceCheck && text.includes(k);
      }
    });
  }

  const handleCaseSelect = (c) => {
    setSelectedCase(c);
    setSelectedEvent(null);
    setTimelineSummary('');
  };

  const handleEventSelect = (evt) => {
    setSelectedEvent(evt);
  };

  // Render call segments (transcript) for a call event.
  function renderCallSegments(segments) {
    return segments.map((seg) => (
      <Box key={seg.segmentId} sx={{ mb: 2, border: '1px solid #ddd', padding: '8px', borderRadius: '4px' }}>
        <Typography variant="subtitle2">
          Segment ID: {seg.segmentId} (Confidence: {seg.aiConfidence || 0}%)
        </Typography>
        <Typography variant="body2" sx={{ fontStyle: 'italic', mb: 1 }}>
          {showGroundTruth ? seg.transcript : seg.transcript}
        </Typography>
        <Typography variant="body2" sx={{ mb: 1 }}>
          <strong>AI Explanation:</strong> {seg.aiExplanation}
        </Typography>
        {seg.audioUrl && (
          <audio controls src={seg.audioUrl} style={{ width: '100%' }}>
            Your browser does not support the audio element.
          </audio>
        )}
      </Box>
    ));
  }

  // Render extracted Q/A for call events.
  function renderExtractedQA(qaArray) {
    return qaArray.map((qa, idx) => (
      <Box key={idx} sx={{ mb: 2, border: '1px solid #ddd', padding: '8px', borderRadius: '4px' }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>
          Q: {qa.question}
        </Typography>
        <Typography variant="body2">
          A: {qa.answer}
        </Typography>
      </Box>
    ));
  }

  // Build text timeline summary for copy/paste.
  function buildTimelineSummary() {
    if (!selectedCase) {
      setTimelineSummary("No case selected. Please select a case first.");
      return;
    }
    const events = getFilteredEvents();
    if (!events.length) {
      setTimelineSummary("No events found for the current filters.");
      return;
    }
    const lines = [`Timeline for ${selectedCase.caseId}:`];
    events.forEach((evt, idx) => {
      lines.push(`(${idx + 1}) ${evt.timestamp} - ${evt.eventType} - ${evt.shortDescription || 'No summary'}`);
    });
    setTimelineSummary(lines.join("\n"));
  }

  // Render legend for event types.
  function renderLegend() {
    return (
      <Paper variant="outlined" sx={{ p: 1, mb: 2, backgroundColor: 'background.paper' }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>Legend</Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Box sx={{ width: 20, height: 20, backgroundColor: 'orange', mr: 1 }} />
          <Typography variant="body2">Call</Typography>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Box sx={{ width: 20, height: 20, backgroundColor: '#4caf50', mr: 1 }} />
          <Typography variant="body2">Transaction</Typography>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Box sx={{ width: 20, height: 20, backgroundColor: '#2196f3', mr: 1 }} />
          <Typography variant="body2">Login</Typography>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Box sx={{ width: 20, height: 20, backgroundColor: 'red', mr: 1 }} />
          <Typography variant="body2">Alert</Typography>
        </Box>
      </Paper>
    );
  }

  // Render table of events.
  function renderEventTable(events) {
    return (
      <TableContainer component={Paper} sx={{ mt: 2 }}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Time</TableCell>
              <TableCell>Type</TableCell>
              <TableCell>Summary</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {events.map(evt => (
              <TableRow key={evt.eventId}>
                <TableCell>{evt.timestamp}</TableCell>
                <TableCell>{evt.eventType}</TableCell>
                <TableCell>{evt.shortDescription || "(No summary)"}</TableCell>
                <TableCell>
                  <Button variant="outlined" size="small" onClick={() => handleEventSelect(evt)}>
                    Details
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    );
  }

  // Render event details.
  function renderEventDetails() {
    if (!selectedEvent) return null;
    return (
      <Paper sx={{ p: 2, m: 2, backgroundColor: 'background.paper' }}>
        <Typography variant="h6">Event Details</Typography>
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
            {selectedEvent.eventType} @ {selectedEvent.timestamp}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Event ID: {selectedEvent.eventId}
          </Typography>
          {selectedEvent.textSummary && (
            <Typography variant="body2" sx={{ mt: 1 }}>
              <strong>Copyable Summary:</strong> {selectedEvent.textSummary}
            </Typography>
          )}
        </Box>

        {/* For call events with extracted Q/A, render Tabs */}
        {selectedEvent.eventType === 'Call' && selectedEvent.extractedQuestions && selectedEvent.extractedQuestions.length > 0 ? (
          <Box>
            <Tabs value={callDetailTab} onChange={(e, newVal) => setCallDetailTab(newVal)} aria-label="Call detail tabs">
              <Tab label="Transcript" id="call-tab-0" />
              <Tab label="Extracted Q/A" id="call-tab-1" />
            </Tabs>
            <TabPanel value={callDetailTab} index={0}>
              {selectedEvent.callSegments?.length > 0 ? (
                renderCallSegments(selectedEvent.callSegments)
              ) : selectedEvent.transcript ? (
                <Paper sx={{ p: 1, backgroundColor: 'background.paper' }}>
                  <Typography variant="body2">{selectedEvent.transcript}</Typography>
                </Paper>
              ) : null}
            </TabPanel>
            <TabPanel value={callDetailTab} index={1}>
              {renderExtractedQA(selectedEvent.extractedQuestions)}
            </TabPanel>
          </Box>
        ) : (
          // Fallback rendering for non-call events or call events without extracted Q/A.
          <>
            {selectedEvent.callSegments?.length > 0 && (
              <Box sx={{ mb: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <Typography variant="subtitle2" sx={{ mr: 2 }}>Show Ground Truth?</Typography>
                  <Switch checked={showGroundTruth} onChange={e => setShowGroundTruth(e.target.checked)} />
                </Box>
                {renderCallSegments(selectedEvent.callSegments)}
              </Box>
            )}
            {selectedEvent.transcript && !selectedEvent.callSegments?.length && (
              <Box sx={{ mb: 2 }}>
                <Typography variant="subtitle2">Transcript/Alert Info:</Typography>
                <Paper sx={{ p: 1, backgroundColor: 'background.paper' }}>
                  <Typography variant="body2">{selectedEvent.transcript}</Typography>
                </Paper>
              </Box>
            )}
          </>
        )}

        {selectedEvent.referencedTransactions?.length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2">Referenced Transactions:</Typography>
            <Paper sx={{ p: 1, backgroundColor: 'background.paper' }}>
              <Typography variant="body2">{selectedEvent.referencedTransactions.join(", ")}</Typography>
            </Paper>
          </Box>
        )}

        {selectedEvent.details && Object.keys(selectedEvent.details).length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2">Event Details:</Typography>
            <Paper sx={{ p: 1, backgroundColor: 'background.paper' }}>
              {Object.entries(selectedEvent.details).map(([k, v]) => (
                <Typography key={k} variant="body2"><strong>{k}:</strong> {v}</Typography>
              ))}
            </Paper>
          </Box>
        )}

        {selectedEvent.audioUrl && !selectedEvent.callSegments?.length && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2">Audio:</Typography>
            <audio controls src={selectedEvent.audioUrl} style={{ width: '100%' }}>
              Your browser does not support the audio element.
            </audio>
          </Box>
        )}

        {(selectedEvent.aiConfidence !== undefined) && (!selectedEvent.callSegments?.length) && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2">AI Insights:</Typography>
            <Paper sx={{ p: 1, backgroundColor: 'background.paper' }}>
              <Typography variant="body2"><strong>Confidence:</strong> {selectedEvent.aiConfidence}%</Typography>
              <Typography variant="body2"><strong>Explanation:</strong> {selectedEvent.aiExplanation}</Typography>
            </Paper>
          </Box>
        )}
      </Paper>
    );
  }

  const filteredEvents = getFilteredEvents();

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        {/* HEADER */}
        <AppBar position="static">
          <Toolbar>
            <Typography variant="h6" sx={{ flexGrow: 1 }}>
              Fraud Investigation Dashboard
            </Typography>
            <Box sx={{
              display: 'flex',
              alignItems: 'center',
              backgroundColor: 'rgba(255,255,255,0.15)',
              borderRadius: 1,
              mr: 2, ml: 2,
              p: '2px 8px'
            }}>
              <Search />
              <InputBase
                placeholder="Search transcripts..."
                inputProps={{ 'aria-label': 'search' }}
                sx={{ ml: 1, color: 'inherit' }}
                value={keyword}
                onChange={e => setKeyword(e.target.value)}
              />
            </Box>
            <IconButton color="inherit"><Notifications /></IconButton>
            <IconButton color="inherit"><Settings /></IconButton>
            <IconButton color="inherit"><Help /></IconButton>
            <IconButton color="inherit" onClick={() => setDarkMode(!darkMode)}>
              {darkMode ? <Brightness7 /> : <Brightness4 />}
            </IconButton>
          </Toolbar>
        </AppBar>

        <MainContainer>
          {/* LEFT SIDEBAR */}
          <Sidebar variant="permanent" anchor="left">
            <Typography variant="h6" gutterBottom>Filters</Typography>
            <Typography variant="subtitle2" sx={{ mt: 2 }}>Event Types</Typography>
            <FormGroup>
              <FormControlLabel
                control={<Checkbox checked={showCall} onChange={e => setShowCall(e.target.checked)} />}
                label="Call"
              />
              <FormControlLabel
                control={<Checkbox checked={showTransaction} onChange={e => setShowTransaction(e.target.checked)} />}
                label="Transaction"
              />
              <FormControlLabel
                control={<Checkbox checked={showLogin} onChange={e => setShowLogin(e.target.checked)} />}
                label="Login"
              />
              <FormControlLabel
                control={<Checkbox checked={showAlert} onChange={e => setShowAlert(e.target.checked)} />}
                label="Alert"
              />
            </FormGroup>

            <Typography variant="subtitle2" sx={{ mt: 2 }}>Min Confidence: {confidenceLevel}%</Typography>
            <Slider value={confidenceLevel} onChange={(e, val) => setConfidenceLevel(val)} step={1} min={0} max={100} />

            <Typography variant="subtitle2" sx={{ mt: 2 }}>Keyword</Typography>
            <TextField
              size="small"
              fullWidth
              placeholder="Search text..."
              value={keyword}
              onChange={e => setKeyword(e.target.value)}
              sx={{ mb: 2 }}
            />

            <Typography variant="h6" sx={{ mt: 2 }}>Cases</Typography>
            <List>
              {filteredCases.map(c => (
                <ListItem button key={c.caseId} onClick={() => handleCaseSelect(c)}>
                  <ListItemText primary={c.caseId} secondary={c.summary} />
                </ListItem>
              ))}
            </List>
          </Sidebar>

          {/* MIDDLE COLUMN: Timeline & Event Details */}
          <TimelineColumn>
            <TimelineContainer>
              <Typography variant="h6">Timeline</Typography>
              <Typography variant="body2" color="text.secondary">
                Click markers to see event details
              </Typography>

              {renderLegend()}

              <TimelineBar>
                <TimelineLabel leftPos="0%">00:00</TimelineLabel>
                <TimelineLabel leftPos="25%">06:00</TimelineLabel>
                <TimelineLabel leftPos="50%">12:00</TimelineLabel>
                <TimelineLabel leftPos="75%">18:00</TimelineLabel>
                <TimelineLabel leftPos="100%">24:00</TimelineLabel>

                {filteredEvents.map(evt => (
                  <TimelineMarker
                    key={evt.eventId}
                    leftPos={computeLeftPosition(evt.timestamp)}
                    color={eventColor(evt.eventType)}
                    onClick={() => handleEventSelect(evt)}
                  />
                ))}
              </TimelineBar>

              {renderEventTable(filteredEvents)}
            </TimelineContainer>

            {/* Event Details rendered below the timeline */}
            {renderEventDetails()}
          </TimelineColumn>

          {/* RIGHT COLUMN: Case Summary & Timeline Summary */}
          <DetailColumn>
            {/* Case Summary Panel */}
            <Paper sx={{ p: 2, backgroundColor: 'background.paper' }}>
              <Typography variant="h6">Case Summary</Typography>
              {selectedCase ? (
                <Box>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mt: 1 }}>
                    {selectedCase.caseId}
                  </Typography>
                  <Typography variant="body2" sx={{ mt: 1 }}>
                    {selectedCase.summary}
                  </Typography>
                  {selectedCase.overallAiInsight && (
                    <Paper sx={{ p: 1, backgroundColor: 'background.paper', mt: 1 }}>
                      <Typography variant="body2">
                        <strong>Overall AI Confidence:</strong> {selectedCase.overallAiInsight.confidence}%
                      </Typography>
                      <Typography variant="body2">
                        <strong>Explanation:</strong> {selectedCase.overallAiInsight.summaryExplanation}
                      </Typography>
                    </Paper>
                  )}
                </Box>
              ) : (
                <Typography variant="body2">Select a case to see details.</Typography>
              )}
            </Paper>

            {/* Timeline Summary Panel */}
            <Paper sx={{ p: 2, flexGrow: 1, backgroundColor: 'background.paper' }}>
              <Typography variant="h6">Timeline Summary</Typography>
              <Button variant="contained" onClick={buildTimelineSummary} disabled={!selectedCase} sx={{ mt: 1, mb: 1 }}>
                Generate Timeline Summary
              </Button>
              <TextField
                multiline
                rows={6}
                fullWidth
                value={timelineSummary}
                onChange={() => {}}
                label="Copy/Paste Summary"
              />
            </Paper>
          </DetailColumn>
        </MainContainer>

        {/* FOOTER */}
        <FooterBar>
          <Typography variant="body2">Connected. Last updated: 2 minutes ago.</Typography>
          <Typography variant="body2">Version: 1.0.0</Typography>
          <Box>
            <Button color="inherit" size="small">Help</Button>
            <Button color="inherit" size="small">Feedback</Button>
            <Button color="inherit" size="small">Terms of Service</Button>
          </Box>
        </FooterBar>
      </div>
    </ThemeProvider>
  );
}
